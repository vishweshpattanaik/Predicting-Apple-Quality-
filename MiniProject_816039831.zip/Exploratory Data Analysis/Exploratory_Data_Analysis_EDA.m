% Load the data from the "FruitData.csv" file using readmatrix
dataset = readmatrix('Apples.csv');

% Extract attribute names from the first row of the CSV file
file = fopen('Apples.csv', 'r');
attribute_labels = strsplit(fgetl(file), ',', 'CollapseDelimiters', false);
fclose(file);

% Extract quality labels from the last column of the data
quality_indicators = strcmp(dataset(:, end), 'good'); % Convert "good" to logical true (1), "bad" to logical false (0)
data = dataset(:, 2:end-1); % Exclude ID and quality columns

% Plot histograms and curve for each attribute
num_features = size(data, 2);
for j = 1:num_features
    % Create a figure and histogram
    figure;
    [frequency, bin_edges] = histcounts(data(:, j));
    bin_width = bin_edges(2) - bin_edges(1);
    bar(bin_edges(1:end-1) + bin_width/2, frequency, 'BarWidth', 1, 'FaceColor',"#4DBEEE");
    hold on;
    
    % Compute mean and standard deviation of data
    mean_value = mean(data(:, j));
    std_dev = std(data(:, j));
    
    % Generate x values 
    x_values = linspace(min(data(:, j)), max(data(:, j)), 100);
    
    % Compute y values 
    y_values = exp(-0.5 * ((x_values - mean_value) / std_dev).^2) / (std_dev * sqrt(2 * pi));
    
    % Scale the curve to match the frequency
    y_scaled = y_values * sum(frequency) * bin_width;
    
    % Plot the scaled curve
    plot(x_values, y_scaled, "Color","#D95319",'LineWidth', 1.5);
    
    % Plot a vertical line for Zero Line 
    y_limits = get(gca, 'YLim');
    line([0 0], y_limits, 'Color', 'k', 'LineStyle', '--');
    
    % Set title and labels
    title(sprintf('Histogram of Frequency vs %s', attribute_labels{j+1})); % Skip the ID column
    xlabel(attribute_labels{j+1});
    ylabel('Frequency');
    
    % Add legend
    legend('Histogram', 'Curve');
    
    hold off;
end
